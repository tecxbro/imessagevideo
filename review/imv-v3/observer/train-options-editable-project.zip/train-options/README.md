# Train options editable project

The four-second delivery is `train-options.mp4`. Edit picture layers and
timeline in `scene.json`. The authored comparison input is `reference.mp4`.
The Sound plan is `skill/imessage-motion-recreation/sound/recreation/train.plan.json`.
The four individual WAV cue stems are under
`review/imv-v3/sound/recreation/final/cue-stems/`.

Use Python 3.11 or later, Node.js, FFmpeg/ffprobe with libx264, and Chromium.
Run from the extracted project's root.

```sh
S=skill/imessage-motion-recreation
R=review/imv-v3/sound/recreation
npm ci --prefix "$S/scripts/engines"
python3 -m pip install -r "$S/sound/requirements.txt"
sha256sum -c SHA256SUMS
python3 "$S/observer/imv.py" render scene.json --method html --out /tmp/train-picture.mp4
python3 "$S/sound/sound.py" verify "$S/sound/recreation/train.plan.json" /tmp/train-picture.mp4 train-options.mp4 "$R/final/manifest.json"
python3 "$S/sound/sound.py" mix "$S/sound/recreation/train.plan.json" /tmp/train-picture.mp4 /tmp/train-new-mix
```

The shape, message and picker layers remain individually editable. After
a picture edit, resolve the Sound plan against the new silent export.
