# The Moon Cue editable project

`the-moon-cue.mp4` is the approved 15-second delivery. `picture.mp4` is
the corresponding 360-frame silent lock. Edit `direction/film/edit.json`
for copy and scene anchors, `direction/film/stage.py` for the physical art,
and `score/locked/a.json` for audio. Original audio assets and four editable
48 kHz stems are in `score/`.

The conversation adapter included here is the original film skin at
`9beea91a43c0b24fb7a2061ea54071d426f621c6`. The picture uses
`931fe2d0dd8b7f6cc3a38f3e6b1e27e8bd2cb1a3` and the mix uses
`1ba37bbda6d52c82c7a44cd7fd523c0c8035e5d2`. Keeping the original skin
with the project preserves the lock's geometry after later adapter updates.

Use Python 3.11 or later, FFmpeg with libx264, ffprobe, fontconfig and the
DejaVu Sans and Serif faces. Install the pinned dependencies in a virtual
environment, then run these commands from the extracted project.

```sh
python3 -m pip install -r direction/film/requirements.txt -r sound/requirements.txt
sha256sum -c SHA256SUMS
python3 direction/film/render.py --out /tmp/moon-picture.mp4
python3 sound/sound.py verify score/locked/a.json /tmp/moon-picture.mp4 the-moon-cue.mp4 score/locked/a/manifest.json
python3 sound/sound.py mix score/locked/a.json /tmp/moon-picture.mp4 /tmp/moon-new-mix
python3 observer/imv.py verify /tmp/moon-new-mix/mix.mp4 --scene /tmp/moon-picture.events.json
```

The published picture SHA-256 is
`838fbb35fa9741cb373875d2c6f88536c2dd46ab6abc39978e47a1d7f978cec7`.
The published finished film SHA-256 is
`c2c818d7a4dcd5bfb87ac5587f576854b563dcb7f2a9027bb3641be25975dadf`.
