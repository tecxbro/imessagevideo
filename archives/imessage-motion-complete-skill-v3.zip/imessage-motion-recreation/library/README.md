# Complete private example library

The compact skill includes design/direction instructions, visual atlases, real shared renderers, nine neutral editable components, nine motion starters and fourteen source studies. Full measured example projects and finished films are larger and live in the private Drive library. manifest.json makes every archive and part addressable by observed file IDs, byte count and SHA256.

Each of the six complete project packs contains the full accepted scene (including its complete path/keyframe data), every declared image/font asset, all five real shared adapter implementations, five explicit per-format entry wrappers, the source movie, five finished reference-audio movies, capture/provenance records, source-comparison evidence and retained per-example authoring programs. These are the actual accepted scenes/adapters; the nine neutral starters are a separate new-design layer.

The authored implementation is a shared scene model plus genuine Remotion React, GSAP timeline, HTML/SVG evaluator, native Motion Canvas and Pillow renderers. Standalone independently rewritten projects for each film/method were not authored, and this library does not pretend otherwise. It includes the actual shared code and explicit run entrypoints for each example/method. Figma remains a clearly marked unvalidated prototype.

Additional archives preserve the original frozen visual delivery byte-for-byte, thirty silent picture masters, all retained authored executable code and fixtures, the complete UI audio source with its previously omitted reports/stock archives/license pages, pinned font inputs/Linux fallbacks, later director/UI source, and the research/retrieval tools. Dependency installations, browser binaries, third-party installer resources and reproducible frame caches are not authored source; install/recreate them using the pinned environment instructions.

## How an agent retrieves a project

Read RESEARCH-FIRST.md for a new company. Resolve the desired example and format in manifest.json. Run `python library/materialize.py plan --archive 05-linq-complete-v1` for the observed private Drive files and required checks. Use the authorized Personal Drive connection, confirm metadata, then fetch each part with download_raw_file=true/include_base64=false. Materialize the returned top-level file_uri. Every part is at most24MiB, below the download tool's32MiB limit.

Record the returned local paths in a JSON object such as `{"1":"/path/part001","2":"/path/part002"}`. Then:

```bash
python library/materialize.py assemble --archive 05-linq-complete-v1 \
  --part-map local-parts.json --out work/05-linq.zip --extract-to work/project
```

The helper checks every part, the assembled archive and internal pack checksums; it rejects traversal/symlink entries and refuses to overwrite different existing source files. Each pack's checksum map is saved under `.library-receipts`, so a visual case, audio source and font dependencies can share one working project. Keep different case projects and historical source snapshots in separate working folders when their example-specific documentation differs. Choose a volume large enough for the expanded scene: full path data can be hundreds of megabytes. Never store authenticated signed download URLs or credentials in the skill.

Open the materialized project's README-COMPLETE-EXAMPLE.md. `tools/render_example.py` creates fresh caches, runs genuine adapters, applies measured Pillow sampling overrides, uses the validated full-range BT.709 encode, and muxes the reference audio with Rene's explicit cut. Existing results are frozen targets, not overwritten. The separate portable workflow helpers close old audio/Sites path assumptions. Historical authoring programs are included as source history and may require superseded measurement inputs; the accepted scene+adapter cold-build path is the supported reproduction route.

## Visuals and code together

`index.html` pairs example/result selection with full renderer source and the private project registry. The existing director explorer supplies source/rebuild filmstrips, component anatomy and editable starters. Finished films are also inside the case packs for offline review. Inspect actual frames before adapting a motion; a filename or code snippet is not visual understanding.

This library remains private to the selected Drive account. The public gallery contains the previously authorized visual studies and videos. Publishing the new full source/font library was blocked by automatic approval review; do not work around that boundary or change file sharing without explicit authorization.
