---
name: imessage-motion-recreation
description: Research a company, direct or recreate Apple Messages launch motion, and retrieve complete private example projects with their actual code, assets and five rendered formats. Use visual studies, editable UI components, measured choreography, real rendering engines and UI sound.
---

# iMessage motion director

Version 3 combines direction instructions, visual studies, component code and access to the complete private example library. It is not trained model weights or an autonomous video generator. Act as a director: research the product, determine its promise, choose visual evidence, establish component anatomy, plan motion and sound, then render and judge the result.

For a new company or product, start with [RESEARCH-FIRST.md](library/RESEARCH-FIRST.md) and produce an evidence-backed profile using [company-profile.schema.json](library/company-profile.schema.json) **before choosing motion or writing the shot plan**. Use supplied/connected context, the official site, primary docs and real UI. Record citations, observed facts, inferences and unresolved gaps; do not invent product capabilities, transactions, integrations or results. Investigate ambiguous names before asking one focused clarification.

## Route the task

| User goal | Start here | Timing authority |
|---|---|---|
| Make a film for a new company | [Company research](library/RESEARCH-FIRST.md), [profile schema](library/company-profile.schema.json), then the director workflow | Verified product evidence and a newly authored shot plan |
| Recreate a supplied film | [Reconstruction playbook](references/reconstruction-playbook.md), actual movie and native-frame comparisons | Actual source with explicit output/source mapping |
| Direct a new film using these ideas | [Director workflow](director/directing.md), [visual explorer](director/index.html), [design grammar](director/design-grammar.md) | A new shot plan, labelled as authored choreography |
| Extract or adapt a component | [Component contracts](director/component-contracts.md), [component code](director/components.mjs), chosen study | Declared editable boundary and actual source evidence |
| Add UI sound | [UI audio workflow](references/ui-audio-workflow.md) | Visible actions in the delivered picture |

For recreation, catalogue recipes help decompose the source; never replace its motion with a starter preset. For new direction, catalogue options carry tradeoffs; never claim a new starter is source-exact.

## Retrieve complete examples on demand

Read [library/README.md](library/README.md), inspect the [library browser](library/index.html), and resolve the required project/results in [library/manifest.json](library/manifest.json). The selected storage is the user's **Personal private Drive folder**: [complete library](https://drive.google.com/drive/folders/1RnlqjEO4KywzL7pnCPpz7IX5eYMIVzsO). Registry records with observed Drive IDs, byte counts and SHA256 establish availability; an upload plan or filename does not. Do not invent IDs, part counts or completion claims.

The six measured examples use **one complete scene JSON and its assets plus genuine shared adapters** for Remotion, GSAP, HTML/SVG, Pillow and native Motion Canvas. Per-format CLI wrappers select that actual implementation; independently rewritten per-format scene projects were not authored. A complete case pack includes the full accepted geometry/keyframes, every declared image/font asset, adapters/wrappers, reference, five finished results, provenance/comparisons and retained authoring code. Additional registered archives preserve the frozen delivery, silent masters, retained source/fixtures, complete UI-audio inputs and font inputs. Read the registry's exact contents; snippets and neutral starters do not replace these projects.

Follow the installed Drive skill/tool schemas and use the authorized Personal private Drive connection in this order. The materializer requires Python 3.11 or later.

1. Run `python3 library/materialize.py list`, then `python3 library/materialize.py plan --archive ARCHIVE_ID` using an actual ID from the manifest. Retrieve the smallest complete project needed; load history only for diagnosis.
2. Confirm each recorded Drive file's metadata, then use Drive `fetch` with `download_raw_file=true` and `include_base64=false`. Metadata alone is not the archive payload.
3. Materialize the returned top-level `file_uri`. For `sediment://file_...`, call `download_file` with the bare file ID; use a returned local workspace path directly. Parts are bounded to 24 MiB. Record the resulting local paths in a part-map JSON; keep signed URLs and credentials out of logs/skill files.
4. Assemble and extract with `library/materialize.py`, which verifies part, archive and internal payload hashes and rejects unsafe paths. For example, replace `ARCHIVE_ID` with the selected registry ID:

   ```bash
   python3 library/materialize.py assemble --archive ARCHIVE_ID \
     --part-map work/local-parts.json --out work/case.zip --extract-to work/project
   ```

5. Read the extracted `README-COMPLETE-EXAMPLE.md` and use `tools/render_example.py` for fresh caches, genuine adapters, measured sampling overrides and final encoding. Accepted scene + adapter + wrapper is the supported cold-build route; historical programs may need superseded measurement inputs. Frozen results remain comparison targets.

Keep this library private. A public source-library upload was rejected by automatic approval review; do not bypass that boundary with public links, signed-URL publication or sharing changes. Use the authenticated Drive route above. Figma remains a prototype without a validated Motion/export session, not a completed sixth format.

## Read the relevant knowledge

1. Complete the research/profile step for a new company, then read `director/directing.md`. Extract audience, promise, real user action, proof, runtime, aspect ratio, copy and asset constraints. Consult supplied/connected context before asking for missing information. Choose reasonable reversible defaults; do not invent product capabilities or UI states.
2. Read `director/catalogue.json` and select studies by story purpose. The explainable router in `director/decisions.mjs` suggests options; keyword scores are not creative judgment.
3. **Open and inspect the selected atlas images** with an available image tool. Read the study JSON for native frames, actual canonical IDs/keyframes, parent/clip structure, material and editability caveats. Linking an image does not mean the agent has seen it. Record which frames were inspected.
4. Read `director/design-grammar.md` and selected component contracts. Choose typography, layout, camera and asset boundaries before easing. Reconstruct source-specific assets when required; neutral starters do not contain all original logos, portraits, fonts or rich-card interiors.
5. Write a shot plan: purpose, exact copy, component instances, stable IDs, start/end states, native-frame phases, attention target, camera/clip rules, reading holds, sound anchors, evidence and validation gate. Explain the motif choice and a plausible alternative's tradeoff. Use `director/brief-schema.json` and `director/examples/dinner-shot-plan.json`.

## Motion starters

| Starter | Show | Main constraint |
|---|---|---|
| `message-wall` | Breadth across conversations | Actor identity, row order and readable focus |
| `conversation-handoff` | A request, send and reply | Real composer changes; no fake AI typing |
| `mini-app-expand` | Work inside the conversation | Preserve context and readable controls |
| `app-drawer` | Where a tool is found | One clipped sheet and coherent children |
| `identity-morph` | One identity becoming an app icon | Separate outline, material and internal mark |
| `circle-to-panel` | An action becoming a working surface | New extension, not Poke's measured icon transition |
| `selection-confirm` | A decision and visible result | One control through press and confirmation |
| `camera-focus` | An important detail | Move the camera, preserve local UI geometry |
| `card-orbit` | Offerings converging into a promise | Independent paths, depth and readable settlement |

`director/motions.mjs` implements these nine adaptable scene builders. Keep capability/effect counts grounded in the actual catalogue. Starter timing is newly authored. The source studies contain measured motion and disclose when native poses, masks, source-specific paths or raster interiors prevent simple parameter replacement.

## Components and exposed UI

`director/components.mjs` provides nine editable builders: MessageBubble, Composer, AppIcon, AppCard, BottomSheet, PhoneFrame, ActionButton, Avatar and CameraRig. They emit the same scene contract used by the real renderers. Preserve stable child IDs, explicit copy/line breaks, independent camera/content groups and correct clipping. Replace the disclosed Arial fallback with verified production typography and remeasure it.

Open `director/index.html` for a standalone visual explorer. It works from the extracted folder without an account/server, displays the starters and component anatomy, scrubs by frame, suggests motifs from a brief and exports scene, cue and SVG files. It contains no AI model and does not automatically finish a film, export video or create a Figma file.

```bash
node director/cli.mjs plan --brief "Show booking inside a conversation"
node director/cli.mjs scene --motif mini-app-expand --out work/scene.json
node scripts/engines/render.mjs --method gsap --scene work/scene.json --out work/preview.mp4
```

Read [RUNNING.md](RUNNING.md) for dependencies. Remotion, GSAP, HTML/SVG, Pillow and native Motion Canvas were executed in the original project. Reprobe capabilities in each new environment. The Figma converter remains a prototype without a validated Motion API session; follow installed Figma skills before attempting it.

## Frame and sound discipline

Read `director/analysis/index.json`: bundled CSVs cover all 7,499 aligned native output frames across the six films, with source mapping and residual error. Atlas images show selected teaching phases, not every frame. Canonical trajectory samples describe reconstructed states; pixel comparisons independently measure visual differences. Neither certifies perceptual perfection.

For exact work, scan every aligned frame numerically, rank separated error peaks and inspect source, reconstruction and foreground differences near those peaks. Verify dimensions, rational cadence, lifecycle boundaries, transform composition, blur, materials, masks and editability. Preserve canonical hashes and outside-range proofs. Use `scripts/shared/SCHEMA.md`, verification tools and the reconstruction playbook.

Sound follows actions. Prefer licensed provenance-pinned clicks/real single keys when suitable, procedural accents for gaps, actual pauses and intentional silence. Do not sound titles, AI text, caret blinks or composer clearing. Start with UI only; music is optional. Check attacks/onsets, sample span, headroom and encoded true peaks. Retrieve complete sound inputs, sources, stems and license/provenance records through the private library manifest; the compact skill carries the workflow and reference evidence.

## Diagnose and deliver

Before retrying, log the attempt, observed defect/error, evidence, cause or bounded hypothesis, changed variable and next check. Do not repeat unchanged failed operations. Prior corrections remain in [the reconstruction playbook](references/reconstruction-playbook.md), [execution ledger](references/execution-ledger.md) and [director upgrade log](director/upgrade-steps.md).

Deliver company research/evidence, brief/shot plan, component configuration, complete scene/assets/code, visual evidence, cue provenance, renders, comparisons, checks and known limits. Distinguish measured source evidence, authored choreography, inference, editable geometry/text and static imagery. Add accepted new examples to the private registry with hashes and rendered visual references; preserve frozen deliveries. Use `director/package_skill.py` with an explicit new output filename; the legacy packager predates this layer and can overwrite older archive names.
