#!/usr/bin/env python3
"""Render frame-grounded UI events; music is a quiet optional background.

  python audio-recreation/scripts/render_ui.py --id 01-photonhq --plan
  python audio-recreation/scripts/render_ui.py --id 01-photonhq
  python audio-recreation/scripts/render_ui.py --all
  python audio-recreation/scripts/render_ui.py --id 01-photonhq --no-music
  python audio-recreation/scripts/render_ui.py --self-test

Reads only ui-cues/canonical-ID.json, prepared CC0 library assets, declared
procedural fallbacks and the completed NEW music stem. Never opens reference
film audio. Canonical event frames are authoritative; one key per observed
typing/delete/batch update, with no invented subframe character timing.

Writes ui-mixes/ID/{ui,music,full_mix}.flac/.m4a, ui_preview.m4a and report.
--no-music reads no music file and writes separately under ID/no-music/;
the UI API build_ui(schedule) also works without music or AI generation.
Production UI uses restrained per-event peak targets; only ui_preview gets a
whole-stem listening boost to approximately−5dBFS. Background music is−6dB
relative to the existing validated new-music stem. No−16LUFS raising occurs.
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import library_bank as library
from render_mix import SAMPLE_RATE, decode, encode, loudness, sha256, stats, validate_export
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from synthesis import render as synthesize

KINDS = {'typing', 'delete', 'tap', 'message_send', 'message_arrival', 'typing_burst',
         'text_select', 'cart_update', 'panel_open', 'panel_close', 'control_appear'}
TARGET_PEAKS = {'typing': -18., 'delete': -18.5, 'typing_burst': -18.,
                'tap': -14., 'message_send': -12., 'message_arrival': -12.,
                'text_select': -16., 'cart_update': -15., 'panel_open': -21., 'panel_close': -22.}
KEYS = [f'key_{i:03}' for i in library.KEY_SELECTION]
MUSIC_GAIN_DB = -6.
PREVIEW_PEAK_DBFS = -5.


def target_sample(frame: int, schedule: dict) -> int:
    return round(Fraction(frame * schedule['fps_denominator'] * SAMPLE_RATE, schedule['fps_numerator']))


def load_schedule(ident: str) -> tuple[dict, Path]:
    path = ROOT / 'ui-cues' / f'canonical-{ident}.json'
    if not path.is_file():
        raise FileNotFoundError(f'Canonical visual event schedule is not released: {path}')
    data = json.loads(path.read_text())
    if data['id'] != ident or data['frames'] < 1 or data['fps_numerator'] <= 0 or data['fps_denominator'] <= 0:
        raise ValueError('Invalid canonical ID/frame-rate/span')
    if data.get('sample_count', target_sample(data['frames'], data)) != target_sample(data['frames'], data):
        raise ValueError('Canonical picture sample count disagrees with exact native cadence')
    for e in data['events']:
        if e['kind'] not in KINDS or not isinstance(e['frame'], int) or not 0 <= e['frame'] < data['frames']:
            raise ValueError(f'Invalid event kind/frame: {e}')
        exact = e['frame'] * data['fps_denominator'] / data['fps_numerator']
        if 'time' in e and abs(e['time'] - exact) > 1e-4:
            raise ValueError(f'Event time disagrees with its authoritative native frame: {e}')
        if e.get('sample_offset_48000', target_sample(e['frame'], data)) != target_sample(e['frame'], data):
            raise ValueError('Canonical event sample offset disagrees with native frame')
        if e['kind'] in {'typing', 'typing_burst', 'delete'} and e.get('role') in {'assistant', 'ai', 'title'}:
            raise ValueError('Typing events cannot be inferred from AI responses or title reveals')
    return data, path


def render_event(e: dict, schedule: dict, ordinal: int) -> tuple[np.ndarray, dict]:
    kind = e['kind']; policy = e.get('audio', {})
    peak = float(policy.get('target_peak_dbfs', TARGET_PEAKS[kind]))
    pan = float(policy.get('pan', e.get('pan', 0.)))
    pitch = float(policy.get('pitch', e.get('pitch', 1.12 if kind == 'message_send' else 1.)))
    if not math.isfinite(peak) or peak > -6 or not -1 <= pan <= 1:
        raise ValueError('Per-event peak target must leave at least6dB headroom and pan must be−1..1')
    seed = int.from_bytes(hashlib.sha256(f'{schedule["id"]}:{e["frame"]}:{kind}:{ordinal}'.encode()).digest()[:4], 'big')
    if kind in {'typing', 'typing_burst', 'delete'}:
        asset_id = policy.get('asset_id', KEYS[seed % len(KEYS)])
        if not asset_id.startswith('key_'):
            raise ValueError('Typing must use the actual single-key recording pool')
    elif kind == 'tap':
        asset_id = policy.get('asset_id', 'kenney_click_001')
    elif kind == 'message_arrival':
        asset_id = policy.get('asset_id', 'kenney_drop_001')
    elif kind == 'text_select':
        asset_id = policy.get('asset_id', 'kenney_select_001')
    elif kind == 'cart_update':
        asset_id = policy.get('asset_id', 'kenney_tick_001')
    else:
        asset_id = policy.get('asset_id')
    if asset_id:
        entries = {a['id']: a for a in library.manifest()['assets']}
        if asset_id not in entries:
            raise ValueError(f'Unknown prepared stock asset {asset_id}')
        a = entries[asset_id]
        clip = library.render_asset(asset_id, pitch=pitch, gain_db=peak + 6, pan=pan)
        source = {'kind': a['source_kind'], 'asset_id': asset_id, 'license': a['license'],
                  'original_sha256': a['original_sha256'], 'prepared_sha256': a['prepared_sha256'],
                  'source_collection': a['source'], 'asset_gain_db': peak + 6,
                  'routing_limit': 'Filename/category-based original sound design; not a proprietary-sound equivalence claim'}
    else:
        # The pack names do not establish a short airy send whoosh. This is
        # an explicitly original generated fallback, never called a recording.
        effect = policy.get('synth_effect', 'card_swoosh' if kind == 'panel_open' else 'air_whoosh')
        duration = policy.get('duration', .22 if kind == 'panel_open' else .18 if kind == 'panel_close' else .14)
        clip = synthesize(effect, pitch=pitch, duration=duration,
                          energy=.75, pan=pan, seed=seed)
        clip *= 10 ** (peak / 20) / float(np.max(np.abs(clip)))
        source = {'kind': 'original_procedural_fallback', 'effect': effect, 'seed': seed,
                  'parameters': {'pitch': pitch, 'duration': duration, 'energy': .75, 'pan': pan},
                  'code_sha256': sha256(ROOT / 'synthesis/ui_synth.py'), 'recorded_samples_used': False}
    alignment = 'onset' if kind in {'message_send', 'panel_open', 'panel_close'} else 'dominant_early_attack_peak'
    if policy.get('alignment'):
        alignment = policy['alignment']
    if alignment not in {'onset', 'dominant_early_attack_peak'}:
        raise ValueError('Unknown alignment policy')
    peak_offset = library.attack_peak_sample(clip) if alignment == 'dominant_early_attack_peak' else 0
    wanted = target_sample(e['frame'], schedule)
    # A nonzero peak cannot coincide with a required zero first sample. The
    # sole boundary exception is one sample, reported explicitly if needed.
    boundary_adjustment = int(wanted == 0 and peak_offset > 0)
    start = wanted + boundary_adjustment - peak_offset
    receipt = {'canonical_event': e, 'ordinal': ordinal, 'source': source,
               'target_peak_dbfs': peak, 'pitch': pitch, 'pan': pan,
               'alignment': alignment, 'event_sample': wanted, 'clip_alignment_offset_samples': peak_offset,
               'clip_start_sample_unclipped': start, 'boundary_adjustment_samples': boundary_adjustment,
               'clip_samples': len(clip), 'batch_policy': 'one actual key for one observed update; no subframe times inferred'
               if kind == 'typing_burst' else 'one effect for one canonical event'}
    return clip.astype(np.float64), receipt


def build_ui(schedule: dict) -> tuple[np.ndarray, list[dict]]:
    count = target_sample(schedule['frames'], schedule)
    ui = np.zeros((count, 2), dtype=np.float64); receipts = []
    for ordinal, event in enumerate(schedule['events']):
        if event['kind'] == 'control_appear':
            receipts.append({'canonical_event': event, 'ordinal': ordinal, 'rendered': False,
                             'skip_reason': 'A control becoming visible is not an observed tap; silent by default',
                             'source': {'kind': 'silent_visual_state', 'audio_file_used': None}})
            continue
        clip, record = render_event(event, schedule, ordinal)
        start = record['clip_start_sample_unclipped']
        crop_start = max(0, -start); target_start = max(0, start)
        length = min(len(clip) - crop_start, count - target_start)
        if length <= 0:
            raise ValueError('Event clip falls wholly outside the picture')
        piece = clip[crop_start:crop_start + length].copy()
        truncated_end = len(clip) - crop_start - length
        if truncated_end:
            release = min(round(.004 * SAMPLE_RATE), len(piece) // 2)
            if release:
                piece[-release:] *= np.cos(np.linspace(0, np.pi / 2, release))[:, None] ** 2
        ui[target_start:target_start + length] += piece
        record.update({'rendered': True, 'written_start_sample': target_start, 'written_samples': length,
                       'trimmed_start_samples': crop_start, 'trimmed_end_samples': len(clip) - crop_start - length,
                       'alignment_error_samples': record['boundary_adjustment_samples']})
        receipts.append(record)
    ui[[0, -1]] = 0
    return ui, receipts


def listening(path: Path, samples: np.ndarray, count: int, bitrate: str) -> dict:
    encode(path, samples, aac=True, bitrate=bitrate)
    first = validate_export(path, count, None, aac=True, enforce_peak=False)
    tp = first['loudness']['true_peak_dbtp']
    correction = min(0., -1.65 - tp) if tp is not None and tp > -1.5 else 0.
    if correction:
        encode(path, samples * 10 ** (correction / 20), aac=True, bitrate=bitrate)
        final = validate_export(path, count, None, aac=True)
    else:
        if first['clipped_samples']:
            raise ValueError('AAC clipping without a measured true-peak explanation')
        final = first
    return {'file': final, 'codec_gain_db': correction,
            'first_pass_if_corrected': first if correction else None, 'bitrate': bitrate}


def music_bed(ident: str, count: int, *, no_music: bool = False) -> tuple[np.ndarray, dict]:
    if no_music:
        return np.zeros((count, 2), dtype=np.float64), {
            'kind': 'silent_bed_no_music_input', 'music_input_used': False,
            'input_file': None, 'sha256': None, 'new_score_provenance': [],
            'old_sfx_stem_used': False, 'gain_db': 0., 'ai_generation_required': False}
    music_path = ROOT / 'mixes' / ident / 'music.flac'
    music_report_path = music_path.parent / 'mix-report.json'
    old = json.loads(music_report_path.read_text())
    if old['validation']['status'] != 'pass' or old['source_samples_reused'] or sha256(music_path) != old['exports']['music.flac']['sha256']:
        raise ValueError('The new-music-only stem lacks valid unchanged provenance')
    music = decode(music_path).astype(np.float64)
    if len(music) != count:
        raise ValueError('New music stem and canonical picture sample spans disagree')
    music *= 10 ** (MUSIC_GAIN_DB / 20)
    return music, {'kind': 'validated_new_music_stem', 'music_input_used': True,
                   'input_file': str(music_path.relative_to(ROOT)), 'sha256': sha256(music_path),
                   'new_score_provenance': old['audio_inputs'], 'old_sfx_stem_used': False, 'gain_db': MUSIC_GAIN_DB}


def render_one(ident: str, *, no_music: bool = False) -> dict:
    schedule, schedule_path = load_schedule(ident)
    count = target_sample(schedule['frames'], schedule)
    library_manifest = library.manifest()
    for a in library_manifest['assets']:
        if sha256(library.ROOT / a['prepared_file']) != a['prepared_sha256']:
            raise ValueError('Prepared library asset changed after its provenance capture')
    music, music_info = music_bed(ident, count, no_music=no_music)
    ui, events = build_ui(schedule)
    raw_full = music + ui
    measured = loudness(raw_full)
    tp = measured['true_peak_dbtp']
    common_gain_db = min(0., -1.8 - tp) if tp is not None else 0.
    gain = 10 ** (common_gain_db / 20)
    stems = {'ui': ui * gain, 'music': music * gain, 'full_mix': raw_full * gain}
    peak = float(np.max(np.abs(stems['ui'])))
    preview_gain_db = PREVIEW_PEAK_DBFS - 20 * math.log10(peak) if peak else 0.
    preview = stems['ui'] * 10 ** (preview_gain_db / 20)
    output = ROOT / 'ui-mixes' / ident
    if no_music:
        output = output / 'no-music'
    output.mkdir(parents=True, exist_ok=True)
    report = {'format_version': 1, 'id': ident, 'status': 'rendering', 'reference_film_samples_reused': False,
              'licensed_library_samples_used': any(e.get('rendered') and e['source']['kind'] != 'original_procedural_fallback' for e in events),
              'procedural_fallbacks_used': any(e['source']['kind'] == 'original_procedural_fallback' for e in events),
              'schedule_sha256': sha256(schedule_path), 'schedule_file': str(schedule_path.relative_to(ROOT)),
              'library_manifest_sha256': sha256(library.ROOT / 'manifest.json'),
              'code_sha256': sha256(Path(__file__)), 'library_api_sha256': sha256(Path(library.__file__)),
              'codec_helpers_sha256': sha256(Path(__file__).parent / 'render_mix.py'),
              'music': music_info,
              'picture': {k: schedule[k] for k in ['frames', 'fps_numerator', 'fps_denominator']},
              'sample_rate': SAMPLE_RATE, 'channels': 2, 'samples': count,
              'canonical_event_count': len(events), 'rendered_event_count': sum(bool(e.get('rendered')) for e in events),
              'skipped_event_count': sum(not e.get('rendered') for e in events),
              'kind_counts': dict(Counter(e['canonical_event']['kind'] for e in events)),
              'rendered_kind_counts': dict(Counter(e['canonical_event']['kind'] for e in events if e.get('rendered'))),
              'events': events, 'production_ui_before_guard': stats(ui), 'raw_full': {**stats(raw_full), 'loudness': measured},
              'common_peak_guard_gain_db': common_gain_db, 'loudness_raising_applied': False,
              'ui_preview': {'whole_stem_boost_db': preview_gain_db, 'target_sample_peak_dbfs': PREVIEW_PEAK_DBFS,
                             'purpose': 'Clearly labelled listening boost; production UI remains separate at its designed level'},
              'exports': {}}
    for name, samples in stems.items():
        samples[[0, -1]] = 0
        flac = output / f'{name}.flac'
        encode(flac, samples, aac=False)
        report['exports'][flac.name] = validate_export(flac, count, None, aac=False)
        m4a = output / f'{name}.m4a'
        report['exports'][m4a.name] = listening(m4a, samples, count, '128k' if name == 'music' else '192k')
    report['exports']['ui_preview.m4a'] = listening(output / 'ui_preview.m4a', preview, count, '192k')
    decoded = {name: decode(output / f'{name}.flac') for name in stems}
    error = float(np.max(np.abs(decoded['music'] + decoded['ui'] - decoded['full_mix'])))
    if error > 3 / (2 ** 23):
        raise ValueError('Lossless UI/music stems do not sum within24bit quantization')
    report['validation'] = {'status': 'pass', 'finite_no_clipping': True, 'picture_sample_span_exact': True,
                            'no_reference_audio_inputs': True, 'no_inferred_subframe_keystrokes': True,
                            'stem_sum_max_error': error, 'stem_sum_domain': 'PCM24 FLAC; AAC copies independently codec validated',
                            'production_and_boosted_preview_separate': True}
    report['status'] = 'pass'
    (output / 'schedule.snapshot.json').write_bytes(schedule_path.read_bytes())
    (output / 'render_ui.source.py.txt').write_bytes(Path(__file__).read_bytes())
    temporary = output / 'report.tmp.json'; temporary.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    temporary.replace(output / 'report.json')
    print(json.dumps({'id': ident, 'status': 'pass', 'events': len(events), 'samples': count,
                      'preview_gain_db': preview_gain_db, 'output': str(output)}, indent=2))
    return report


def self_test() -> None:
    schedule = {'id': 'self-test', 'frames': 90, 'fps_numerator': 30, 'fps_denominator': 1,
                'events': [{'frame': 10, 'kind': 'typing', 'audio': {'asset_id': 'key_001'}}]}
    x, receipts = build_ui(schedule)
    assert len(x) == 144000 and len(receipts) == 1
    assert np.argmax(np.max(np.abs(x), axis=1)) == 16000
    again, _ = build_ui(schedule); assert np.array_equal(x, again)
    schedule['events'] = [{'frame': 20, 'kind': 'typing_burst', 'delta_count': 5}]
    _, receipts = build_ui(schedule); assert len(receipts) == 1 and receipts[0]['canonical_event']['delta_count'] == 5
    schedule['events'] = [{'frame': 20, 'kind': 'message_send'}]
    _, receipts = build_ui(schedule); assert receipts[0]['clip_start_sample_unclipped'] == 32000
    assert receipts[0]['source']['recorded_samples_used'] is False
    schedule['events'] = [{'frame': 20, 'kind': 'control_appear'}, {'frame': 22, 'kind': 'text_select'},
                          {'frame': 24, 'kind': 'cart_update'}, {'frame': 30, 'kind': 'panel_open'}]
    _, receipts = build_ui(schedule)
    assert not receipts[0]['rendered'] and receipts[1]['source']['asset_id'] == 'kenney_select_001'
    assert receipts[2]['source']['asset_id'] == 'kenney_tick_001'
    assert receipts[3]['source']['effect'] == 'card_swoosh' and receipts[3]['alignment'] == 'onset'
    silent, provenance = music_bed('nonexistent-no-ai-test', 800, no_music=True)
    assert silent.shape == (800, 2) and not np.any(silent)
    assert provenance['music_input_used'] is False and provenance['input_file'] is None
    assert provenance['new_score_provenance'] == [] and provenance['ai_generation_required'] is False
    print(json.dumps({'status': 'pass', 'checks': ['actual recorded key peak aligned exactly to native frame',
                       'deterministic source choice', 'one sound per observed batch update', 'send onset alignment',
                       'explicit stock-versus-procedural provenance', 'silent control appearances retained as skipped',
                       'selection/cart/panel routing', 'no-music path requires no music file or AI provenance']}))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--id'); group.add_argument('--all', action='store_true'); group.add_argument('--self-test', action='store_true')
    parser.add_argument('--plan', action='store_true')
    parser.add_argument('--no-music', action='store_true', help='No music input required; write separately under ID/no-music/')
    args = parser.parse_args()
    try:
        if args.self_test:
            self_test(); return
        ids = ['01-photonhq', '02-danieltian', '03-photon-mini', '04-poke', '05-linq', '06-gallery'] if args.all else [args.id]
        if args.plan:
            print(json.dumps({ident: load_schedule(ident)[0] for ident in ids}, indent=2)); return
        for ident in ids:
            render_one(ident, no_music=args.no_music)
    except (ValueError, FileNotFoundError, KeyError, RuntimeError) as error:
        parser.exit(2, f'UI audio render failed: {error}\n')


if __name__ == '__main__':
    main()
