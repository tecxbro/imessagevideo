#!/usr/bin/env python3
"""Mix NEW music and original synthesized UI sounds; never read source audio.

From the project root:
  python audio-recreation/scripts/render_mix.py --id 01-photonhq
  python audio-recreation/scripts/render_mix.py --all
  python audio-recreation/scripts/render_mix.py --all --plan
  python audio-recreation/scripts/render_mix.py --self-test

Input: audio-recreation/ai/ID/music.mp3 + its text-only provenance.json.
Recipe: audio-recreation/mix-config.json; sparse optional cue metadata only.
Outputs per ID: music/sfx/full_mix.flac (48 kHz stereo PCM24), matching M4A
previews, mix-report.json and README.md. No persistent WAV intermediates.

FFmpeg loudnorm measures integrated LUFS/true peak, then one shared static
gain normalizes both stems and their sum. If the peak ceiling misses the
target by more than 1 LU, a linked oversampled lookahead limiter controls the
same six music/SFX/sum channels together. Stem additivity, cue balance and
digital silence are validated. No reference soundtrack or original
video/audio stream is accepted as a mixer input.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import subprocess
import sys

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
sys.path.insert(0, str(ROOT))
from synthesis import SAMPLE_RATE, render as synthesize

DEFAULT_VIDEOS = Path('/workspace/sites/message-motion/dist/videos.json')


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_ffmpeg(arguments: list[str], samples: np.ndarray | None = None) -> subprocess.CompletedProcess:
    command = ['ffmpeg', '-hide_banner', '-loglevel', 'info', '-threads', '1', '-filter_threads', '1'] + arguments
    result = subprocess.run(command, input=None if samples is None else np.asarray(samples, dtype='<f4').tobytes(),
                            capture_output=True)
    if result.returncode:
        raise RuntimeError('FFmpeg failed: ' + result.stderr.decode(errors='replace')[-3000:])
    return result


def pcm_input() -> list[str]:
    return ['-f', 'f32le', '-ar', str(SAMPLE_RATE), '-ac', '2', '-i', 'pipe:0']


def decode(path: Path) -> np.ndarray:
    # All production calls are guarded: only a new AI music file or a mix
    # export from this script reaches this helper. No reference path is read.
    result = run_ffmpeg(['-i', str(path), '-map', '0:a:0', '-ar', str(SAMPLE_RATE), '-ac', '2',
                         '-f', 'f32le', '-acodec', 'pcm_f32le', '-threads', '1', 'pipe:1'])
    x = np.frombuffer(result.stdout, dtype='<f4').reshape(-1, 2).copy()
    if not len(x) or not np.isfinite(x).all():
        raise ValueError(f'Empty or nonfinite decoded audio: {path}')
    return x


def loudness(x: np.ndarray) -> dict:
    if not np.any(x):
        return {'integrated_lufs': None, 'true_peak_dbtp': None, 'lra_lu': 0.0, 'silent': True}
    result = run_ffmpeg(pcm_input() + ['-af', 'loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json', '-f', 'null', '-'], x)
    matches = re.findall(r'\{\s*"input_i"[\s\S]*?\}', result.stderr.decode(errors='replace'))
    if not matches:
        raise RuntimeError('FFmpeg loudnorm did not return a measurement')
    values = json.loads(matches[-1])
    def number(key: str):
        value = float(values[key])
        return value if math.isfinite(value) else None
    return {'integrated_lufs': number('input_i'), 'true_peak_dbtp': number('input_tp'),
            'lra_lu': number('input_lra'), 'threshold_lufs': number('input_thresh'), 'silent': False}


def stats(x: np.ndarray) -> dict:
    if x.ndim != 2 or x.shape[1] != 2 or not np.isfinite(x).all():
        raise ValueError('Expected finite stereo samples')
    peak = float(np.max(np.abs(x)))
    return {'samples_per_channel': len(x), 'duration_s': len(x) / SAMPLE_RATE,
            'sample_peak': peak, 'sample_peak_dbfs': 20 * math.log10(peak) if peak else None,
            'rms': float(np.sqrt(np.mean(np.asarray(x, dtype=np.float64) ** 2))),
            'finite': True, 'clipped_samples': int(np.count_nonzero(np.abs(x) >= 1)),
            'endpoints_zero': bool(np.all(x[[0, -1]] == 0))}


def picture_samples(film: dict) -> int:
    p = film['picture']
    return round(Fraction(p['frames'] * p['fps_denominator'] * SAMPLE_RATE, p['fps_numerator']))


def fade_envelope(film: dict, count: int, guard: float) -> tuple[np.ndarray, int]:
    envelope = np.ones(count, dtype=np.float64)
    attack = min(count, max(2, round(film['fade_in_s'] * SAMPLE_RATE)))
    envelope[:attack] *= np.sin(np.linspace(0, np.pi / 2, attack)) ** 2
    # Leave 50 ms before mandated Mini/Daniel silence so AAC's synthesis
    # window cannot smear an audible tail beyond that explicit deadline.
    end_s = film['silence_by_s'] - (guard if film['keep_remainder_silent'] else 0)
    end = min(count, max(1, round(end_s * SAMPLE_RATE)))
    start = min(end - 1, max(0, round(film['fade_start_s'] * SAMPLE_RATE)))
    envelope[start:end] *= np.cos(np.linspace(0, np.pi / 2, end - start)) ** 2
    envelope[end:] = 0
    envelope[[0, -1]] = 0
    return envelope, end


def duck_envelope(events: list[dict], count: int, maximum_db: float) -> tuple[np.ndarray, dict]:
    depths = np.zeros(count, dtype=np.float64)
    for event in events:
        depth = min(maximum_db, max(0.0, event['parameters']['duck_db']))
        if depth == 0:
            continue
        when = event['sample_offset']
        start = max(0, when - round(.075 * SAMPLE_RATE))
        hold_end = min(count, when + round(min(event['parameters']['duration'], .22) * SAMPLE_RATE))
        end = min(count, hold_end + round(.24 * SAMPLE_RATE))
        local = np.ones(end - start)
        attack = when - start
        if attack:
            local[:attack] = np.sin(np.linspace(0, np.pi / 2, attack)) ** 2
        if end > hold_end:
            local[hold_end - start:] = np.cos(np.linspace(0, np.pi / 2, end - hold_end)) ** 2
        # Max, not sum: nearby cues never pile up into excessive ducking.
        depths[start:end] = np.maximum(depths[start:end], local * depth)
    return 10 ** (-depths / 20), {'maximum_depth_db': float(depths.max()),
                                 'ceiling_db': maximum_db, 'overlap_rule': 'maximum, never sum',
                                 'attack_s': .075, 'release_s': .24}


def event_recipe(film: dict, mapping: dict, count: int) -> list[dict]:
    recipe = []
    for event in film['events']:
        if event.get('omit_by_default'):
            continue
        parameters = dict(mapping[event['category']])
        parameters.update(event.get('overrides', {}))
        if parameters['effect'] not in {'bubble_pop', 'touch_click', 'key_tap', 'air_whoosh', 'card_swoosh',
                                        'glass_confirm', 'low_impact', 'digital_sparkle'}:
            raise ValueError('Effect must belong to the original synthesis bank')
        offset = round(event['output_time'] * SAMPLE_RATE)
        if not 0 <= offset < count:
            raise ValueError(f'Cue falls outside picture: {event}')
        parameters['seed'] = film['seed'] + event['cue_index']
        parameters['pan'] = round(.12 * math.sin(event['cue_index'] * 2.399963), 5)
        recipe.append({**event, 'sample_offset': offset, 'parameters': parameters})
    if not 8 <= len(recipe) <= 24:
        raise ValueError(f'Expected a sparse 8–24 event recipe, got {len(recipe)}')
    return recipe


def sound_effects(recipe: list[dict], count: int) -> np.ndarray:
    stem = np.zeros((count, 2), dtype=np.float64)
    for event in recipe:
        p = event['parameters']
        clip = synthesize(p['effect'], pitch=p['pitch'], duration=p['duration'], energy=p['energy'], pan=p['pan'], seed=p['seed'])
        start = event['sample_offset']
        length = min(len(clip), count - start)
        stem[start:start + length] += clip[:length] * (10 ** (p['gain_db'] / 20))
    return stem


def linked_peak_control(music: np.ndarray, sfx: np.ndarray, ceiling_db: float) -> tuple[dict, dict]:
    """One shared lookahead gain across two stems AND their sum, in RAM.

    Six-channel packing makes FFmpeg's linked detector see both stem peaks
    and sum peaks, while applying exactly the same gain to every channel.
    Four-times resampling improves true-peak control; delay compensation
    retains sample alignment. No six-channel files are written.
    """
    packed = np.column_stack([music, sfx, music + sfx]).astype('<f8')
    limit = 10 ** (ceiling_db / 20)
    filters = (f'aresample=192000,alimiter=limit={limit:.12f}:attack=5:release=80:'
               'level=false:latency=true,aresample=48000')
    command = ['ffmpeg', '-v', 'error', '-threads', '1', '-filter_threads', '1', '-f', 'f64le',
               '-ar', str(SAMPLE_RATE), '-ac', '6', '-channel_layout', '5.1', '-i', 'pipe:0',
               '-af', filters, '-f', 'f64le', '-c:a', 'pcm_f64le', '-ar', str(SAMPLE_RATE),
               '-ac', '6', '-threads', '1', 'pipe:1']
    process = subprocess.run(command, input=packed.tobytes(), capture_output=True)
    if process.returncode:
        raise RuntimeError('Linked peak control failed: ' + process.stderr.decode(errors='replace'))
    result = np.frombuffer(process.stdout, dtype='<f8').reshape(-1, 6).copy()
    if len(result) != len(packed) or not np.isfinite(result).all():
        raise ValueError('Linked peak control changed sample count or produced nonfinite samples')
    sum_error = float(np.max(np.abs(result[:, :2] + result[:, 2:4] - result[:, 4:6])))
    if sum_error > 1e-12:
        raise ValueError(f'Linked peak control did not preserve stem additivity: {sum_error}')
    return {'music': result[:, :2], 'sfx': result[:, 2:4], 'full_mix': result[:, 4:6]}, {
        'applied': True, 'filter': filters, 'oversample_rate': 192000,
        'shared_channel_order': ['musicL', 'musicR', 'sfxL', 'sfxR', 'sumL', 'sumR'],
        'lookahead_ms': 5, 'release_ms': 80, 'auto_makeup_gain': False,
        'latency_compensated': True, 'stem_sum_max_error_before_quantization': sum_error}


def encode(path: Path, samples: np.ndarray, *, aac: bool, bitrate: str = '256k') -> None:
    if not np.isfinite(samples).all() or np.max(np.abs(samples)) >= 1:
        raise ValueError('Refusing to export nonfinite or clipped samples')
    temporary = path.with_name(path.stem + '.tmp' + path.suffix)
    options = (['-c:a', 'aac', '-b:a', bitrate, '-movie_timescale', str(SAMPLE_RATE), '-movflags', '+faststart'] if aac else
               ['-c:a', 'flac', '-sample_fmt', 's32', '-bits_per_raw_sample', '24', '-compression_level', '8'])
    try:
        run_ffmpeg(['-y'] + pcm_input() + ['-map_metadata', '-1'] + options +
                   ['-ar', str(SAMPLE_RATE), '-ac', '2', '-threads', '1', str(temporary)], samples)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def validate_export(path: Path, count: int, silence_start: int | None, *, aac: bool, enforce_peak: bool = True) -> dict:
    x = decode(path)
    raw_frames = len(x)
    if aac:
        # AAC packets are 1024 samples, with MP4 edit lists defining the exact
        # media duration. Decode may retain a final padded packet.
        if not count <= len(x) <= count + 1024:
            raise ValueError(f'AAC decode sample count is unexpected: {path}: {len(x)} versus {count}')
        x = x[:count]
    elif len(x) != count:
        raise ValueError(f'Lossless sample count mismatch: {path}')
    probe = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'a:0', '-show_entries',
                            'stream=codec_name,sample_rate,channels,bits_per_raw_sample,duration_ts,time_base',
                            '-of', 'json', str(path)], check=True, capture_output=True, text=True)
    stream = json.loads(probe.stdout)['streams'][0]
    if stream['sample_rate'] != str(SAMPLE_RATE) or stream['channels'] != 2:
        raise ValueError(f'Wrong encoded sample rate/channel count: {path}')
    if aac:
        encoded_duration = int(stream['duration_ts']) * Fraction(stream['time_base'])
        if abs(float(encoded_duration) - count / SAMPLE_RATE) > 1 / SAMPLE_RATE:
            raise ValueError(f'MP4 edit-list duration differs from picture: {path}: {encoded_duration}')
    elif stream.get('bits_per_raw_sample') != '24':
        raise ValueError(f'FLAC is not PCM24: {path}: {stream}')
    report = {**stats(x), 'raw_decoded_samples': raw_frames, 'loudness': loudness(x), 'stream': stream,
              'file': path.name, 'bytes': path.stat().st_size, 'sha256': sha256(path)}
    if enforce_peak and report['clipped_samples']:
        raise ValueError(f'Clipping in encoded export: {path}')
    if enforce_peak and report['loudness']['true_peak_dbtp'] is not None and report['loudness']['true_peak_dbtp'] > -1.5:
        raise ValueError(f'True-peak ceiling exceeded in {path}: {report["loudness"]}')
    if silence_start is not None:
        report['tail_peak'] = float(np.max(np.abs(x[silence_start:]))) if silence_start < count else 0
        if report['tail_peak'] > (1e-5 if aac else 0):
            raise ValueError(f'Explicit silent tail is contaminated: {path}: {report["tail_peak"]}')
    if not aac and not report['endpoints_zero']:
        raise ValueError(f'Nonzero lossless endpoint: {path}')
    return report


def render_one(ident: str, config: dict, config_path: Path, videos_path: Path) -> dict:
    film = config['films'][ident]
    policy = config['policy']
    count = picture_samples(film)
    videos = json.loads(videos_path.read_text())
    video = next(v for v in videos if v['id'] == ident)
    exact_seconds = film['picture']['frames'] * film['picture']['fps_denominator'] / film['picture']['fps_numerator']
    if abs(video['duration'] - exact_seconds) > 1e-5:
        raise ValueError(f'Picture metadata and recipe duration disagree for {ident}')
    music_path = (ROOT / film['music_input']).resolve()
    expected = (ROOT / 'ai' / ident / 'music.mp3').resolve()
    if music_path != expected or not music_path.is_file():
        raise FileNotFoundError(f'New AI music missing: {expected}. Generate/download it first; no reference-audio fallback is permitted.')
    provenance_path = music_path.parent / 'provenance.json'
    if not provenance_path.is_file():
        raise FileNotFoundError(f'New-music provenance is required: {provenance_path}')
    provenance = json.loads(provenance_path.read_text())
    if provenance.get('source_kind') != 'new_AI_music_text_only' or provenance.get('reference_audio_used_as_generation_input') is not False:
        raise ValueError('Music provenance must certify new text-only music with no reference-audio conditioning')
    music_sha = sha256(music_path)
    if provenance.get('sha256') != music_sha:
        raise ValueError('New-music hash does not match its generation provenance')
    cue_path = ROOT / film['cue_sheet']
    cue_info = {'file': str(cue_path.relative_to(PROJECT)), 'usage': 'Timing metadata only; no reference samples read', 'available': cue_path.exists()}
    if cue_path.exists():
        cue_info['sha256'] = sha256(cue_path)
        cue_info['recipe_freeze_sha256'] = film['cue_sheet_sha256']
        cue_info['byte_hash_matches_freeze'] = cue_info['sha256'] == film['cue_sheet_sha256']
        # Narrative/confidence annotations may improve independently. The
        # frozen event recipe is the authority: verify every chosen visual
        # time/category/omit field, never adopt new events implicitly.
        sheet = json.loads(cue_path.read_text())
        for event in film['events']:
            cue = sheet['cues'][event['cue_index']]
            if cue.get('omit_by_default') or event['category'] != cue['category'] or event['output_time'] != cue['output_time']:
                raise ValueError(f'Chosen event is omitted or differs from its pinned timing metadata: {event}')
        cue_info['selected_event_fields_verified'] = True
    recipe = event_recipe(film, config['category_mapping'], count)
    music_decoded = decode(music_path)
    original_count = len(music_decoded)
    minimum = min(count, round(film['silence_by_s'] * SAMPLE_RATE)) - round(.1 * SAMPLE_RATE)
    if original_count < minimum:
        raise ValueError(f'New score too short ({original_count / SAMPLE_RATE:.3f}s; need at least {minimum / SAMPLE_RATE:.3f}s). No looping or reference fallback is performed.')
    music = np.zeros((count, 2), dtype=np.float64)
    music[:min(count, original_count)] = music_decoded[:count]
    if original_count < count:
        end = original_count
        start = max(0, end - round(.05 * SAMPLE_RATE))
        music[start:end] *= np.cos(np.linspace(0, np.pi / 2, end - start))[:, None] ** 2
    envelope, actual_fade_end = fade_envelope(film, count, policy['aac_silence_guard_s'])
    music *= envelope[:, None]
    music_initial = loudness(music)
    if music_initial['integrated_lufs'] is None:
        raise ValueError('New music has no measurable program loudness')
    music_premix_gain = policy['music_premix_lufs'] - music_initial['integrated_lufs']
    music *= 10 ** (music_premix_gain / 20)
    duck, duck_report = duck_envelope(recipe, count, min(2., policy['max_music_duck_db']))
    music *= duck[:, None]
    sfx = sound_effects(recipe, count) * envelope[:, None]
    raw_mix = music + sfx
    raw_loudness = loudness(raw_mix)
    desired_gain = policy['target_lufs'] - raw_loudness['integrated_lufs']
    peak_gain = policy['normalization_headroom_dbtp'] - raw_loudness['true_peak_dbtp']
    master_gain = min(desired_gain, peak_gain)
    gain = 10 ** (master_gain / 20)
    stems = {'music': music * gain, 'sfx': sfx * gain, 'full_mix': raw_mix * gain}
    peak_control = {'applied': False}
    if desired_gain - peak_gain > policy.get('linked_peak_control_if_target_miss_lu', float('inf')):
        pre_gain = 10 ** (desired_gain / 20)
        stems, peak_control = linked_peak_control(music * pre_gain, sfx * pre_gain, policy['normalization_headroom_dbtp'])
        controlled_loudness = loudness(stems['full_mix'])
        post_gain = min(policy['target_lufs'] - controlled_loudness['integrated_lufs'],
                        policy['normalization_headroom_dbtp'] - controlled_loudness['true_peak_dbtp'])
        peak_control.update({'input_common_gain_db': desired_gain, 'output_common_gain_db': post_gain,
                             'measured_before_post_gain': controlled_loudness})
        master_gain = desired_gain + post_gain
        stems = {name: x * 10 ** (post_gain / 20) for name, x in stems.items()}
    for x in stems.values():
        x[envelope == 0] = 0
        x[[0, -1]] = 0
    # A shared gain preserves stem additivity before independent PCM24 rounding.
    if not np.allclose(stems['music'] + stems['sfx'], stems['full_mix'], atol=1e-12, rtol=0):
        raise ValueError('Stem additivity failed')
    output = ROOT / 'mixes' / ident
    output.mkdir(parents=True, exist_ok=True)
    (output / 'mix-config.snapshot.json').write_bytes(config_path.read_bytes())
    (output / 'render_mix.source.py.txt').write_bytes(Path(__file__).read_bytes())
    report = {'format_version': 1, 'id': ident, 'source_samples_reused': False,
              'audio_inputs': [{'kind': 'new_AI_music_text_only', 'path': str(music_path.relative_to(PROJECT)),
                                'sha256': music_sha, 'provenance': provenance, 'provenance_sha256': sha256(provenance_path)}],
              'synthesis': {'kind': 'original code oscillators/modal tones/seeded filtered noise',
                            'code': 'audio-recreation/synthesis/ui_synth.py', 'sha256': sha256(ROOT / 'synthesis/ui_synth.py')},
              'mixer_sha256': sha256(Path(__file__)), 'config_sha256': sha256(config_path),
              'reproducibility_artifacts': {'config': 'mix-config.snapshot.json', 'mixer_source': 'render_mix.source.py.txt'},
              'videos_metadata_sha256': sha256(videos_path), 'cue_metadata': cue_info,
              'picture': {**film['picture'], 'exact_duration_fraction': str(Fraction(film['picture']['frames'] * film['picture']['fps_denominator'], film['picture']['fps_numerator'])),
                          'sample_rate': SAMPLE_RATE, 'channels': 2, 'sample_count': count,
                          'rendered_duration_s': count / SAMPLE_RATE, 'sample_rounding_error_s': count / SAMPLE_RATE - exact_seconds},
              'music_edit': {'decoded_input_samples': original_count, 'trimmed_samples': max(0, original_count - count),
                             'padded_silent_samples': max(0, count - original_count), 'looped': False,
                             'fade_start_s': film['fade_start_s'], 'fade_end_sample': actual_fade_end,
                             'silence_deadline_s': film['silence_by_s'], 'remainder_silent': film['keep_remainder_silent']},
              'selected_events': recipe, 'selected_count': len(recipe), 'ducking': duck_report,
              'normalization': {'method': 'FFmpeg loudnorm measured common gain, with optional linked oversampled lookahead peak control',
                                'music_before_premix': music_initial, 'music_premix_gain_db': music_premix_gain,
                                'raw_stems': {'music': stats(music), 'sfx': stats(sfx)},
                                'raw_mix': {**stats(raw_mix), 'loudness': raw_loudness},
                                'target_lufs': policy['target_lufs'], 'true_peak_ceiling_dbtp': policy['true_peak_ceiling_dbtp'],
                                'master_gain_db': master_gain, 'static_gain_would_be_true_peak_limited': peak_gain < desired_gain,
                                'linked_peak_control': peak_control},
              'toolchain': {'python': platform.python_version(), 'numpy': np.__version__,
                            'ffmpeg': subprocess.run(['ffmpeg', '-version'], check=True, capture_output=True, text=True).stdout.splitlines()[0]},
              'exports': {}}
    silence_start = min(count, round(film['silence_by_s'] * SAMPLE_RATE)) if film['keep_remainder_silent'] else None
    for name, samples in stems.items():
        file = output / f'{name}.flac'
        encode(file, samples, aac=False)
        report['exports'][file.name] = validate_export(file, count, silence_start, aac=False)
    preview_first_pass = {}
    for name, samples in stems.items():
        file = output / f'{name}.m4a'
        encode(file, samples, aac=True, bitrate='112k' if name == 'sfx' else '256k')
        preview_first_pass[file.name] = validate_export(file, count, silence_start, aac=True, enforce_peak=False)
    # Low-rate AAC caused a proved >3 dB transient reconstruction overshoot
    # on film01. Use 256k music/full, then measure actual encoded true peaks.
    # If another score needs more margin, apply one measured COMMON preview
    # attenuation to all three files, preserving the preview stem balance.
    maximum_preview_tp = max(r['loudness']['true_peak_dbtp'] for r in preview_first_pass.values()
                             if r['loudness']['true_peak_dbtp'] is not None)
    preview_gain_db = min(0.0, -1.65 - maximum_preview_tp) if maximum_preview_tp > -1.5 else 0.0
    report['listening_codec'] = {'music_full_aac_bitrate': '256k', 'sfx_aac_bitrate': '112k',
                                 'common_additional_gain_db': preview_gain_db,
                                 'first_pass': preview_first_pass if preview_gain_db else None,
                                 'reason': 'Measured lossy-codec reconstruction overshoot' if preview_gain_db else 'No extra attenuation needed'}
    for name, samples in stems.items():
        file = output / f'{name}.m4a'
        if preview_gain_db:
            encode(file, samples * 10 ** (preview_gain_db / 20), aac=True,
                   bitrate='112k' if name == 'sfx' else '256k')
            report['exports'][file.name] = validate_export(file, count, silence_start, aac=True)
        else:
            # First-pass decode already measured this exact encoded file.
            actual = preview_first_pass[file.name]
            if actual['clipped_samples'] or (actual['loudness']['true_peak_dbtp'] is not None and actual['loudness']['true_peak_dbtp'] > -1.5):
                raise ValueError(f'AAC first-pass peak validation failed: {file}')
            report['exports'][file.name] = actual
    decoded_stems = {name: decode(output / f'{name}.flac') for name in stems}
    error = float(np.max(np.abs(decoded_stems['music'] + decoded_stems['sfx'] - decoded_stems['full_mix'])))
    if error > 3 / (2 ** 23):
        raise ValueError(f'Lossless stem sum is inconsistent beyond independent quantization: {error}')
    target_error = report['exports']['full_mix.flac']['loudness']['integrated_lufs'] - policy['target_lufs']
    if abs(target_error) > 1:
        raise ValueError(f'Master is more than1LU from the requested target: {target_error:+.2f}LU')
    report['validation'] = {'status': 'pass', 'lossless_stem_sum_max_error': error,
                            'no_clipping': True, 'finite_stereo': True, 'exact_lossless_sample_counts': True,
                            'silence_tails_preserved': True, 'loudness_target_error_lu': target_error,
                            'normalization_actual': report['exports']['full_mix.flac']['loudness']}
    temporary = output / 'mix-report.tmp.json'
    temporary.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    temporary.replace(output / 'mix-report.json')
    (output / 'README.md').write_text(f'''# {ident}: new audio mix

`full_mix.flac` is the lossless 48 kHz stereo PCM24 master. `music.flac` and `sfx.flac` are matching stems, sharing the same final gain, fade and any linked master peak control; their sum matches within independent 24-bit quantization. Matching M4A files are compact listening copies. The three listening files share an additional {preview_gain_db:.3f} dB codec-headroom adjustment; SFX is never independently loudness-normalized.

Inputs: newly generated text-only AI music and original procedural synthesis only. No reference soundtrack samples were read by the mixer. The optional cue sheet contributes timing/context metadata, not audio. This recipe chooses {len(recipe)} quiet accents and does not expand typing/scroll categories into beat patterns.

Exact picture span: {count} samples at 48 kHz ({count / SAMPLE_RATE:.9f} seconds). Integrated loudness / true peak of the actual FLAC master: {report['exports']['full_mix.flac']['loudness']['integrated_lufs']} LUFS / {report['exports']['full_mix.flac']['loudness']['true_peak_dbtp']} dBTP. Music duck depth never exceeds {duck_report['maximum_depth_db']:.2f} dB.

Reproduce: `python audio-recreation/scripts/render_mix.py --id {ident} --config audio-recreation/mixes/{ident}/mix-config.snapshot.json` from the project root. `mix-report.json` pins every input, code/recipe hash, selected event, gain, sample count and measured export; the exact mixer source is retained as `render_mix.source.py.txt`. FFmpeg loudnorm selects the common gain. Linked oversampled master peak control applied: **{peak_control['applied']}**. It is used only when static peak-safe normalization misses the target by more than1LU, and applies the same detector/gain to music, SFX and their sum. The report records its exact filter, alignment and additivity checks.
''')
    print(json.dumps({'id': ident, 'status': 'pass', 'selected_events': len(recipe), 'samples': count,
                      'master': str(output / 'full_mix.flac'), 'actual_loudness': report['validation']['normalization_actual'],
                      'total_output_bytes': sum(p.stat().st_size for p in output.iterdir() if p.is_file())}, indent=2))
    return report


def self_test(config: dict) -> None:
    expected = [1048000, 2176000, 2016000, 2054853, 2332800, 2372800]
    for (ident, film), wanted in zip(config['films'].items(), expected):
        count = picture_samples(film)
        assert count == wanted, (ident, count)
        envelope, end = fade_envelope(film, count, config['policy']['aac_silence_guard_s'])
        assert envelope[0] == envelope[-1] == 0 and np.all(np.isfinite(envelope))
        if film['keep_remainder_silent']:
            assert np.all(envelope[end:] == 0)
        recipe = event_recipe(film, config['category_mapping'], count)
        assert 8 <= len(recipe) <= 24 and not any(e.get('omit_by_default') for e in recipe)
    count = SAMPLE_RATE
    events = [{'sample_offset': 10000, 'parameters': {'duration': .1, 'duck_db': 2.}},
              {'sample_offset': 11000, 'parameters': {'duration': .1, 'duck_db': 2.}}]
    duck, report = duck_envelope(events, count, 2.)
    assert report['maximum_depth_db'] <= 2 and abs(duck.min() - 10 ** (-2 / 20)) < 1e-12
    event = {'sample_offset': 2000, 'parameters': {'effect': 'bubble_pop', 'duration': .12, 'pitch': 1.,
                                                 'energy': .75, 'pan': 0., 'seed': 12, 'gain_db': -17}}
    a = sound_effects([event], count)
    b = sound_effects([event], count)
    assert np.array_equal(a, b) and np.all(a[:2000] == 0) and np.all(a[2000 + round(.12 * SAMPLE_RATE):] == 0)
    assert stats(a)['clipped_samples'] == 0
    impulse = np.zeros((16384, 2)); impulse[10000] = 1.2
    tiny = impulse * .1
    limited, limiter_report = linked_peak_control(impulse, tiny, -2.2)
    assert len(limited['full_mix']) == len(impulse)
    assert np.argmax(np.max(np.abs(limited['full_mix']), axis=1)) == 10000
    assert limiter_report['stem_sum_max_error_before_quantization'] < 1e-12
    print(json.dumps({'status': 'pass', 'checks': ['six exact sample spans', 'fades and silent tails',
                      'sparse recipes and omitted-cue exclusion', 'overlapping duck depth <=2dB',
                      'deterministic event placement and no clipping',
                      'linked peak-control stem sum and impulse latency']}))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--id')
    choice.add_argument('--all', action='store_true')
    choice.add_argument('--self-test', action='store_true')
    parser.add_argument('--plan', action='store_true', help='Show the frozen sparse recipe without requiring music')
    parser.add_argument('--config', type=Path, default=ROOT / 'mix-config.json')
    parser.add_argument('--videos-json', type=Path, default=DEFAULT_VIDEOS)
    args = parser.parse_args()
    try:
        config = json.loads(args.config.read_text())
        if config['sample_rate'] != SAMPLE_RATE:
            raise ValueError('Mixer and synthesis rate must both be 48 kHz')
        if args.self_test:
            self_test(config)
            return
        ids = list(config['films']) if args.all else [args.id]
        if any(ident not in config['films'] for ident in ids):
            raise ValueError(f'Unknown ID; choose {", ".join(config["films"])}')
        if args.plan:
            print(json.dumps({ident: {'sample_count': picture_samples(config['films'][ident]),
                                     'events': config['films'][ident]['events'],
                                     'music': config['films'][ident]['music_input']} for ident in ids}, indent=2))
            return
        # Preflight missing inputs for --all before producing a partial batch.
        missing = [str(ROOT / config['films'][ident]['music_input']) for ident in ids
                   if not (ROOT / config['films'][ident]['music_input']).is_file()]
        if missing:
            raise FileNotFoundError('New AI music missing: ' + ', '.join(missing) + '. No reference-audio fallback is permitted.')
        for ident in ids:
            render_one(ident, config, args.config, args.videos_json)
    except (ValueError, KeyError, FileNotFoundError, RuntimeError, StopIteration) as error:
        parser.exit(2, f'Audio mix failed: {error}\n')


if __name__ == '__main__':
    main()
